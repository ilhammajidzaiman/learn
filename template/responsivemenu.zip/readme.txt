Author : Muhammad Syakirurohman
Website : http://www.syakirurohman.net

Semua file yang ada di bundle ini bebas di publikasikan dan dibagikan. 
Bebas dipakai untuk pelengkap produk komersil, tapi dilarang menjualnya dan mengganti kredit atau diakuisisi.
Jangan lupa cantumkan kredit link jika ingin memakainya..

~terima kasih~ 